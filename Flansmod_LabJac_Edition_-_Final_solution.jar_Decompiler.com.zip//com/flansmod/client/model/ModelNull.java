package com.flansmod.client.model;

import net.minecraft.client.model.ModelBase;

public class ModelNull extends ModelBase {
}
