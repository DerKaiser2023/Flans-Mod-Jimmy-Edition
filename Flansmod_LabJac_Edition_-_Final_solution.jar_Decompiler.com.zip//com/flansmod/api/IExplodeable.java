package com.flansmod.api;

public interface IExplodeable {
   void explode();
}
