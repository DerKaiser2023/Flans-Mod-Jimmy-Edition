package com.flansmod.common.types;

public interface IFlanItem {
   InfoType getInfoType();
}
