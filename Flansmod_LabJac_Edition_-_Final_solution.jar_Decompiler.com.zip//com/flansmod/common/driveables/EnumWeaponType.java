package com.flansmod.common.driveables;

public enum EnumWeaponType {
   MISSILE,
   BOMB,
   SHELL,
   MINE,
   GUN,
   NONE;
}
