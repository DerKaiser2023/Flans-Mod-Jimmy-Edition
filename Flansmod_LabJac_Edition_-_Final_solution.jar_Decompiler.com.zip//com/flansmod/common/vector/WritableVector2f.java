package com.flansmod.common.vector;

public interface WritableVector2f {
   void setX(float var1);

   void setY(float var1);

   void set(float var1, float var2);
}
