package com.flansmod.common.vector;

public interface ReadableVector4f extends ReadableVector3f {
   float getW();
}
