package com.flansmod.common.vector;

public interface WritableVector3f extends WritableVector2f {
   void setZ(float var1);

   void set(float var1, float var2, float var3);
}
