package cofh.api;

import cpw.mods.fml.common.API;

// $FF: synthetic class
@API(
   apiVersion = "1.7.10R1.0.2",
   owner = "CoFHLib",
   provides = "CoFHAPI"
)
interface package-info {
}
