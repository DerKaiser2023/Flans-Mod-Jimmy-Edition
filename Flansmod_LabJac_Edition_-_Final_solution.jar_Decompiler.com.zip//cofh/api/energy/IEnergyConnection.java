package cofh.api.energy;

import net.minecraftforge.common.util.ForgeDirection;

public interface IEnergyConnection {
   boolean canConnectEnergy(ForgeDirection var1);
}
